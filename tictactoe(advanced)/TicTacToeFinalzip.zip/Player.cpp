#include "Player.h"

Player::Player(Board::Player player):
mPlayer(player)
{
}
